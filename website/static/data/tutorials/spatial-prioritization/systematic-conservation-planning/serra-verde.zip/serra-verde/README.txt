Serra Verde: a synthetic planning region of 60 x 90 cells of 1 km (EPSG:31983), from landschaft's
example data. The sea has no value (it is not part of the problem).

features.tif   8 bands, the habitat suitability (0-1) of: jaguar, lowland_tapir, harpy_eagle, maned_wolf, golden_lion_tamarin, neotropical_otter, araucaria_forest, mangrove
cost.tif       the cost of every cell (thousand USD)
protected.tif  1 in the three existing protected areas
urban.tif      1 in the three cities
condition.tif  the condition of the habitat (0-1)
threats.tif    2 bands, the intensity (0-1) of deforestation and fire
